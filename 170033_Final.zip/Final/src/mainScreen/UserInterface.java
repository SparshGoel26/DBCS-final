package mainScreen;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import create.CreateDatabase;
import create.CreateMethod;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.FileChooser;
import javafx.stage.Window;

public class UserInterface {
	private Label lbl_heading = new Label("Student Registration");
	private Button btn_createTable = new Button("Create Table");
	
	CreateMethod cr = new CreateMethod();
	CreateDatabase cd = new CreateDatabase();
	
	private TextField txt_Browse = new TextField();

	private Button btn_Browse = new Button("Browse");
	protected Window theStage;
	
	private Button btn_generate = new Button("Generate Data");
	
	private Button btn_Upload = new Button("Upload Data");
	
	private Button btn_view = new Button("View");
	
	double totalOfSH = 22.0 / 30.0;

	double totalOfENB = 12.0 / 10.0;
	
	public UserInterface(Pane theRoot) {
		setupLabelUI(lbl_heading, "Arial", 30, 50, Pos.BASELINE_CENTER, 80, 20);
		lbl_heading.setFont(Font.font("Arial", FontWeight.BOLD, 30));

		setupButtonUI(btn_createTable, "Arial", 19, 60, Pos.BASELINE_LEFT, 120, 100);

		setupButtonUI(btn_Browse, "Arial", 19, 50, Pos.BASELINE_CENTER, 300, 175);
		 
		setupTextUI(txt_Browse, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 20, 175, true);
		
		setupButtonUI(btn_Upload, "Arial", 19, 50, Pos.BASELINE_CENTER, 20, 210);
		
		setupButtonUI(btn_generate, "Arial", 19, 50, Pos.BASELINE_CENTER, 150, 210);
		setupButtonUI(btn_view, "Arial", 19, 50, Pos.BASELINE_CENTER, 250, 210);
		
		btn_view.setOnAction(e -> {
			try {
				viewPDF();
			} catch (ClassNotFoundException | SQLException | DocumentException | IOException e1) {
				e1.printStackTrace();
			}
		});
		
		
		btn_Upload.setOnAction(e -> {
			uploadFile();
		});
		
		btn_generate.setOnAction(e -> {
			try {
				sixweeksreport();
			} catch (ClassNotFoundException e1) {
				e1.printStackTrace();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		});
		

		btn_createTable.setOnAction(e -> {
			createTable();
		});

		btn_Browse.setOnAction(new EventHandler<ActionEvent>() {
			public void handle(ActionEvent arg0) {
				FileChooser fileChooser = new FileChooser();
				File selectedFile = fileChooser.showOpenDialog(theStage);
				String name = selectedFile.getPath();
				txt_Browse.setText(name);

				FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("Xlsx files (*.xlsx)",
						"*.xlsx");
				fileChooser.getExtensionFilters().add(extFilter);
			}
		});
		
		
		theRoot.getChildren().addAll(lbl_heading,  btn_createTable, txt_Browse, btn_generate, btn_Browse, btn_Upload, btn_view);

	}


	private void viewPDF() throws SQLException, DocumentException, ClassNotFoundException, IOException {
		
			Document document = new Document();
			PdfWriter.getInstance(document,
					new FileOutputStream("E:/sixweeksdata1.pdf"));
			document.open();
			File f = new File("E:/sixweeksdata1.pdf");

			PdfPTable table = new PdfPTable(2);
			table.addCell("RollNo");
			table.addCell("Big Data Score");
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/bigdata11", "root",
					"root@123");
			Statement st = con.createStatement();
			ResultSet rs = st.executeQuery("Select * from bigdata_score");
			while (rs.next()) {
				table.addCell(rs.getString("Roll_No"));
				table.addCell(rs.getString("calculation"));
			}
			document.add(table);
			document.close();
			Desktop.getDesktop().open(f);
		
		
	}


	private void sixweeksreport() throws ClassNotFoundException, SQLException {
//		btn_View6.setDisable(false);
		double twoWeeksENB = totalOfENB * 6.0;
		double twoWeeksSH = totalOfSH * 12.0;
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3305/bigdata11", "root",
				"root@123");
		String insert = "Select * from bigdata_score;";
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery(insert);
		@SuppressWarnings("unused")
		int id = 0;
		String rollNo, week1sh1, week1sh2, week2sh1, week2sh2, week3sh1_2, week4sh1_2, week5sh1, week5sh2, week6sh1,
				week6sh2, week1enb, week2enb, week3enb, week4enb, week5enb, week6enb;

		while (rs.next()) {
			
			rollNo = rs.getString("Roll_No");
			week1sh1 = rs.getString("Week1_SH1");
			week1sh2 = rs.getString("Week1_SH2");
			week2sh1 = rs.getString("Week2_SH1");
			week2sh2 = rs.getString("Week2_SH2");
			week3sh1_2 = rs.getString("Week3_SH1_2");
			week4sh1_2 = rs.getString("Week4_SH1_2");
			week5sh1 = rs.getString("Week5_SH1");
			week5sh2 = rs.getString("Week5_SH2");
			week6sh1 = rs.getString("Week6_SH1");
			week6sh2 = rs.getString("Week6_SH2");

			week1enb = rs.getString("Week1_ENB");
			week2enb = rs.getString("Week2_ENB");
			week3enb = rs.getString("Week3_ENB");
			week4enb = rs.getString("Week4_ENB");
			week5enb = rs.getString("Week5_ENB");
			week6enb = rs.getString("Week6_ENB");

			double totalscoreofsh = Double.parseDouble(week2sh2) + Double.parseDouble(week2sh1)
					+ Double.parseDouble(week1sh2) + Double.parseDouble(week1sh1) + Double.parseDouble(week3sh1_2)
					+ Double.parseDouble(week4sh1_2) + Double.parseDouble(week5sh2) + Double.parseDouble(week5sh1)
					+ Double.parseDouble(week6sh2) + Double.parseDouble(week6sh1);
			double totalGrade = (totalscoreofsh * twoWeeksSH) / 120;

			int totalscoreofenb = Integer.parseInt(week2enb) + Integer.parseInt(week1enb) + Integer.parseInt(week3enb)
					+ Integer.parseInt(week4enb) + Integer.parseInt(week5enb) + Integer.parseInt(week6enb);
			double totalGradeENB = (totalscoreofenb * twoWeeksENB) / 600;

			double totalSOFBIGDATA = twoWeeksENB + twoWeeksSH;
			double hun = 100.0 / totalSOFBIGDATA;

			double finalscore = (totalGrade + totalGradeENB) * hun;

			Statement stmtfinal = con.createStatement();

			String insertfinal = "UPDATE bigdata_score SET calculation = " + finalscore + " WHERE Roll_No = "
					+ rollNo + ";";
			stmtfinal.executeUpdate(insertfinal);
		}

	}
	
	private void uploadFile() {
	
			String finalcombo = null;
			String txt = txt_Browse.getText();
			
					finalcombo = "bigdata_score";
					create.bigDataScore.insert(finalcombo, txt);
			
	}
		
	
	private void createTable() {
		cd.createD();
		cr.createM();
	}
	
	private void setupTextUI(TextField t, String ff, double f, double w, double d, Pos p, double x, double y,
			boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}
	
	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

}
