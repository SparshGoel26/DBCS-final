package create;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class TableCreation {
	public void createM() {
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/DBCS", "root",
					"SparshGoel@12345");
			String create = "CREATE TABLE IF NOT EXISTS info(" + "Regno INT," + "Rollno INT,"
					+ "Name VARCHAR(50)," + "FatherName VARCHAR(50)," + "MotherName VARCHAR(50),"
					+ "Course VARCHAR(50)," + "Semester VARCHAR(50)," + "Year VARCHAR(50)" + ");";
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(create);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
