package mainScreen;

import java.awt.Desktop;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import create.DatabaseCreation;
import create.TableCreation;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

public class UserInterface {

	public Label lbl_heading = new Label("Student Registration");
	public Label lbl_regno = new Label("Regestration Number:");
	public Label lbl_rollno = new Label("Roll Number:");
	public Label lbl_name = new Label("Name:");
	public Label lbl_fname = new Label("Father Name:");
	public Label lbl_mname = new Label("Mother Name:");
	public Label lbl_course = new Label("Course:");
	public Label lbl_sem = new Label("Semester:");
	public Label lbl_year = new Label("Year:");
	public Label lbl_regno2 = new Label("Regestration Number:");
	public Label lbl_rollno2 = new Label("Roll Number:");
	public Label lbl_name2 = new Label("Name:");
	public Label lbl_fname2 = new Label("Father Name:");
	public Label lbl_mname2 = new Label("Mother Name:");
	public Label lbl_course2 = new Label("Course:");
	public Label lbl_sem2 = new Label("Semester:");
	public Label lbl_year2 = new Label("Year:");
	public Label lbl_deleteWindow = new Label("Delete Window");
	public Label lbl_rollno1 = new Label("Roll Number:");
	public Label lbl_name1 = new Label("Name:");
	public Label lbl_modifyWindow = new Label("Modify Window");

	private TextField txt_regno = new TextField();
	private TextField txt_rollno = new TextField();
	private TextField txt_name = new TextField();
	private TextField txt_fname = new TextField();
	private TextField txt_mname = new TextField();
	private TextField txt_rollno1 = new TextField();
	private TextField txt_name1 = new TextField();
	private TextField txt_rollno2 = new TextField();
	private TextField txt_name2 = new TextField();
	private TextField txt_regno2 = new TextField();
	private TextField txt_fname2 = new TextField();
	private TextField txt_mname2 = new TextField();

	private ComboBox<String> course = new ComboBox<String>();
	private ComboBox<String> sem = new ComboBox<String>();
	private ComboBox<String> year = new ComboBox<String>();
	private ComboBox<String> course2 = new ComboBox<String>();
	private ComboBox<String> sem2 = new ComboBox<String>();
	private ComboBox<String> year2 = new ComboBox<String>();

	ObservableList<String> courselist = FXCollections.observableArrayList();
	ObservableList<String> semlist = FXCollections.observableArrayList();
	ObservableList<String> yearlist = FXCollections.observableArrayList();

	TableCreation cr = new TableCreation();
	DatabaseCreation cd = new DatabaseCreation();

	private Button btn_insert = new Button("Insert");
	private Button btn_delete = new Button("Delete");
	private Button btn_delete1 = new Button("Delete");
	private Button btn_modify = new Button("Modify");
	private Button btn_modify1 = new Button("Modify");
	private Button btn_view = new Button("View PDF");

	Stage deleteStage = new Stage();
	
	public UserInterface(Pane theRoot) {

		setupLabelUI(lbl_heading, "Arial", 30, 50, Pos.BASELINE_CENTER, 80, 20);
		setupLabelUI(lbl_regno, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 70);
		setupLabelUI(lbl_rollno, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 120);
		setupLabelUI(lbl_name, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 170);
		setupLabelUI(lbl_fname, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 220);
		setupLabelUI(lbl_mname, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 270);
		setupLabelUI(lbl_course, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 320);
		setupLabelUI(lbl_sem, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 370);
		setupLabelUI(lbl_year, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 420);
		lbl_heading.setFont(Font.font("Arial", FontWeight.BOLD, 30));

		setupTextUI(txt_regno, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 65, true);
		setupTextUI(txt_rollno, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 115, true);
		setupTextUI(txt_name, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 165, true);
		setupTextUI(txt_fname, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 215, true);
		setupTextUI(txt_mname, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 265, true);

		setupComboUI(course, 150, 50, 230, 315, false);
		setupComboUI(sem, 150, 50, 230, 365, false);
		setupComboUI(year, 150, 50, 230, 415, false);

		courselist.addAll("Stats", "DBCS", "BigData", "Network", "PMF");
		semlist.addAll("1", "2", "3", "4", "5", "6", "7", "8");
		yearlist.addAll("1", "2", "3", "4");

		course.setItems(courselist);
		sem.setItems(semlist);
		year.setItems(yearlist);

		setupButtonUI(btn_insert, "Arial", 19, 50, Pos.BASELINE_LEFT, 30, 450);
		btn_insert.setOnAction(e -> {
			insertValues();
		});

		setupButtonUI(btn_modify, "Arial", 19, 50, Pos.BASELINE_CENTER, 120, 450);
		btn_modify.setOnAction(e -> {
			modifyValue();
		});

		setupButtonUI(btn_delete, "Arial", 19, 50, Pos.BASELINE_LEFT, 250, 450);
		btn_delete.setOnAction(e -> {
			deleteValue();
		});

		setupButtonUI(btn_view, "Arial", 19, 50, Pos.BASELINE_CENTER, 370, 450);
		btn_view.setOnAction(e -> {
			try {
				viewPDF();
			} catch (ClassNotFoundException | SQLException | DocumentException | IOException e1) {
				e1.printStackTrace();
			}
		});

		theRoot.getChildren().addAll(lbl_regno, lbl_rollno, lbl_name, lbl_fname, lbl_mname, lbl_course, lbl_sem,
				lbl_year, lbl_heading, btn_insert, btn_view, txt_regno, txt_rollno, txt_name, txt_fname, txt_mname,
				course, sem, year, btn_modify, btn_delete);

	}

	private void modifyValue() {
		Stage modifyStage = new Stage();
		modifyStage.setTitle("Modify Window");
		Pane newPane = new Pane();

		setupLabelUI(lbl_modifyWindow, "Arial", 30, 50, Pos.BASELINE_CENTER, 120, 20);

		setupButtonUI(btn_modify1, "Arial", 19, 50, Pos.BASELINE_LEFT, 250, 450);

		setupLabelUI(lbl_regno2, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 70);
		setupLabelUI(lbl_rollno2, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 120);
		setupLabelUI(lbl_name2, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 170);
		setupLabelUI(lbl_fname2, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 220);
		setupLabelUI(lbl_mname2, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 270);
		setupLabelUI(lbl_course2, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 320);
		setupLabelUI(lbl_sem2, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 370);
		setupLabelUI(lbl_year2, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 420);
		lbl_modifyWindow.setFont(Font.font("Arial", FontWeight.BOLD, 30));

		setupTextUI(txt_regno2, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 65, true);
		setupTextUI(txt_rollno2, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 115, true);
		setupTextUI(txt_name2, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 165, true);
		setupTextUI(txt_fname2, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 215, true);
		setupTextUI(txt_mname2, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 230, 265, true);

		setupComboUI(course2, 150, 50, 230, 315, false);
		setupComboUI(sem2, 150, 50, 230, 365, false);
		setupComboUI(year2, 150, 50, 230, 415, false);

		course2.setItems(courselist);
		sem2.setItems(semlist);
		year2.setItems(yearlist);

		btn_modify1.setOnAction(e -> {
			modify();
		});
		newPane.getChildren().addAll(lbl_modifyWindow, lbl_regno2, lbl_rollno2, lbl_name2, lbl_fname2, lbl_mname2,
				lbl_course2, lbl_sem2, lbl_year2, txt_regno2, txt_rollno2, txt_name2, txt_fname2, txt_mname2, course2,
				sem2, year2, btn_modify1);

		Scene newScene = new Scene(newPane, 500, 500);
		modifyStage.setScene(newScene);
		modifyStage.show();
	}

	private void modify() {
		int reg = Integer.parseInt(txt_regno2.getText());
		int roll = Integer.parseInt(txt_rollno2.getText());
		String name = txt_name2.getText();
		String fname = txt_fname2.getText();
		String mname = txt_mname2.getText();
		String courseValue = (String) course2.getValue();
		String semValue = (String) sem2.getValue();
		String yearValue = (String) year2.getValue();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/DBCS", "root",
					"SparshGoel@12345");
			con.setAutoCommit(false);
			PreparedStatement pstm = null;

			String sql = "Update info set Regno='" + reg + "', Rollno='" + roll + "', Name='" + name + "', FatherName='"
					+ fname + "', MotherName='" + mname + "', Course='" + courseValue + "', Semester='" + semValue
					+ "', Year='" + yearValue + "' where Rollno='" + roll + "';";
			pstm = (PreparedStatement) con.prepareStatement(sql);
			pstm.execute();
			System.out.println("Record modified Successfully");
			con.commit();
			pstm.close();
			con.close();
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException ex) {
			System.out.println(ex);
		}
	}

	private void deleteValue() {
		Stage deleteStage = new Stage();
		deleteStage.setTitle("Delete Window");
		Pane newPane = new Pane();

		setupLabelUI(lbl_deleteWindow, "Arial", 30, 50, Pos.BASELINE_CENTER, 120, 20);
		setupLabelUI(lbl_rollno1, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 80);
		setupLabelUI(lbl_name1, "Arial", 20, 50, Pos.BASELINE_CENTER, 30, 140);

		setupTextUI(txt_rollno1, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 160, 80, true);
		setupTextUI(txt_name1, "Arial", 19, 250, 150, Pos.BASELINE_LEFT, 160, 140, true);

		setupButtonUI(btn_delete1, "Arial", 19, 50, Pos.BASELINE_LEFT, 250, 200);
		btn_delete1.setOnAction(e -> {
			delete();
		});
		newPane.getChildren().addAll(lbl_deleteWindow, lbl_rollno1, lbl_name1, txt_rollno1, txt_name1, btn_delete1);

		Scene newScene = new Scene(newPane, 450, 350);
		deleteStage.setScene(newScene);
		deleteStage.show();
	}

	private void delete() {
		int roll = Integer.parseInt(txt_rollno1.getText());
		String name = txt_name1.getText();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/DBCS", "root",
					"SparshGoel@12345");
			con.setAutoCommit(false);
			PreparedStatement pstm = null;

			String sql = "DELETE from info where RollNo='" + roll + "' && Name='" + name + "';";
			pstm = (PreparedStatement) con.prepareStatement(sql);
			pstm.execute();
			System.out.println("Record deleted Successfully");
			con.commit();
			pstm.close();
			con.close();
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException ex) {
			System.out.println(ex);
		}
	}

	private void insertValues() {
		cd.createD();
		cr.createM();
		int reg = Integer.parseInt(txt_regno.getText());
		int roll = Integer.parseInt(txt_rollno.getText());
		String name = txt_name.getText();
		String fname = txt_fname.getText();
		String mname = txt_mname.getText();
		String courseValue = course.getValue();
		String semValue = sem.getValue();
		String yearValue = year.getValue();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/DBCS", "root",
					"SparshGoel@12345");
			con.setAutoCommit(false);

			PreparedStatement pstm = null;

			String sql = "INSERT INTO info VALUES('" + reg + "','" + roll + "','" + name + "','" + fname + "','" + mname
					+ "','" + courseValue + "','" + semValue + "','" + yearValue + "');";
			pstm = (PreparedStatement) con.prepareStatement(sql);
			pstm.execute();
			System.out.println("Inserted the Record into table");
			con.commit();
			pstm.close();
			con.close();
		} catch (ClassNotFoundException e) {
			System.out.println(e);
		} catch (SQLException ex) {
			System.out.println(ex);
		}

	}

	private void viewPDF() throws SQLException, DocumentException, ClassNotFoundException, IOException {
		Document document = new Document();
		PdfWriter.getInstance(document, new FileOutputStream("E:/Registration.pdf"));
		document.open();
		File f = new File("E:/Registration.pdf");

		PdfPTable table = new PdfPTable(8);
		table.addCell("Reg_No");
		table.addCell("Roll_No");
		table.addCell("Name");
		table.addCell("Father_Name");
		table.addCell("Mother_Name");
		table.addCell("Course");
		table.addCell("Semester");
		table.addCell("Year");
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/DBCS", "root", "SparshGoel@12345");
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery("Select * from info");
		while (rs.next()) {
			table.addCell(rs.getString("Regno"));
			table.addCell(rs.getString("Rollno"));
			table.addCell(rs.getString("Name"));
			table.addCell(rs.getString("FatherName"));
			table.addCell(rs.getString("MotherName"));
			table.addCell(rs.getString("Course"));
			table.addCell(rs.getString("Semester"));
			table.addCell(rs.getString("Year"));
		}
		document.add(table);
		document.close();
		Desktop.getDesktop().open(f);
	}

	private void setupTextUI(TextField t, String ff, double f, double w, double d, Pos p, double x, double y,
			boolean e) {
		t.setFont(Font.font(ff, f));
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setAlignment(p);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupComboUI(ComboBox<String> t, double w, double d, double x, double y, boolean e) {
		t.setMinWidth(w);
		t.setMaxWidth(w);
		t.setLayoutX(x);
		t.setLayoutY(y);
		t.setEditable(e);
	}

	private void setupLabelUI(Label l, String ff, double f, double w, Pos p, double x, double y) {
		l.setFont(Font.font(ff, f));
		l.setMinWidth(w);
		l.setAlignment(p);
		l.setLayoutX(x);
		l.setLayoutY(y);
	}

	private void setupButtonUI(Button b, String ff, double f, double w, Pos p, double x, double y) {
		b.setFont(Font.font(ff, f));
		b.setMinWidth(w);
		b.setAlignment(p);
		b.setLayoutX(x);
		b.setLayoutY(y);
	}

}
